# INFORMATION MANAGEMENT PLATFORM (IM Platform)

Master Project Archive, Development History, Architecture, Governance, Current State & Future Roadmap

Archive date: 2026-10-09  |  Owner / product lead: Bousher Adi

AUTHORITY BOUNDARY: This document is a continuity/onboarding synthesis. It does not modify, supersede or recreate frozen technical authorities. Exact primary artifact bytes + SHA-256 + formal governance evidence always win over this narrative.

## 0. Start here - purpose of this package

This package is designed so a future ChatGPT/Claude session, developer, BIM/Information Manager, partner, decision-maker or the owner can reopen the project and understand the complete direction without restarting the architecture. It is not a verbatim export of every chat line; it is a structured synthesis of the project conversation history and available artifacts, with pointers to exact primary evidence.

Use it for three purposes: (1) understand what the platform is and why it exists; (2) continue technical or non-code development from the correct current state; (3) locate the exact authority/evidence files before changing any governed scope.

## 1. Project in two minutes

IM Platform is an owner-side Information Product Governance Platform. It started as a practical BIM quality-control chain for Revit data and has evolved into a governed information layer between requirements/source deliveries and downstream databases, FM/AIM, GIS, CDE, APIs and digital-twin use cases. Its core value is not visualisation; it is the evidence-backed decision chain that determines which information may be trusted, why, against which exact requirements, for which project/building/stage/delivery context, and after which human approvals.

The platform currently has a mature governed validation core, requirement/reference authority, validation context, issue/correction/review/delivery approval, approval gate, canonical information product, persistence/history, and strong immutable-evidence practices. CI-01 Slice 1 (Change Intelligence V1 narrow scope) is now ACCEPTED, PROMOTED, FINAL and FROZEN as exact V0.12 bytes. DP-01 deployment/productization remains deliberately NOT ACCEPTED / NOT PROMOTED / NOT FINAL / NOT FROZEN because its formal closure left acceptance criteria NOT_PROVEN; this must remain visible and must not be silently upgraded.

The next product-development step is Product Workspace Walking Skeleton: a thin read-oriented workspace that exposes governed projects, information states, CI change sets, review/evidence and approval status without changing frozen Core or CI authorities. After that come AIS / Verified Publish / Current, Baseline & Change Control, governed no-code onboarding, legacy-source adapters, and pilot/customer packaging.

## 2. Product thesis and problem

The original problem was practical: owner requirements may exist in documents while BIM/source deliveries contain incomplete, inconsistent or misleading information. Traditional model review tools can show geometry and issues, but they do not by themselves establish organisational truth. IM Platform was therefore shaped around an owner-side governance question: what exact information may be trusted, against which requirement, from which source, in which context, after which review and approval, with what evidence?

The platform complements Revit, Dynamo, Solibri, Navisworks, CDE, FM and GIS. It does not try to replace authoring tools. Instead, it governs the information product that leaves those tools and enters the owner organisation.

## 3. Truth hierarchy and non-negotiable governance rules

- Exact artifact bytes + SHA-256 + primary acceptance/promotion/final/freeze evidence outrank narrative summaries.

- Frozen authorities are immutable. Any technical change requires a separately authorized successor; never hot-patch frozen bytes.

- Source truth > preview. A browser view, newer filename or client payload does not become truth without governed identity and evidence.

- Correction Approval != Delivery Approval != Organisation Acceptance != AIS != Verified Publish/Current.

- Fresh source + revalidation are required before canonical/current publication.

- Fail closed on stale, ambiguous, missing, inconsistent or unverifiable authority/evidence.

- Never silently guess identity/version and never use an implicit 'latest' fallback in governed execution.

- Compare-Before-Write is required where governed source writeback exists.

- Failed attempts and NOT_PROVEN states are evidence. Preserve them; do not rerun merely to manufacture green.

- One proven authority scope cannot silently prove another.

- Customer-specific rules belong in governed Requirement/Reference data, not customer-specific code forks.



## 4. Master information flow

```text
SOURCE WORLD
Revit / Dynamo / IFC / later DWG / PDF / Excel / GIS / Scan / CDE / FM
        |
        v
SOURCE IDENTITY + NORMALIZATION
        |
        v
GOVERNED PROJECT / BUILDING / STAGE / DELIVERY CONTEXT
        |
        +-------------------------------+
        |                               |
        v                               v
REQUIREMENT AUTHORITY             REFERENCE AUTHORITY
        |                               |
        +---------------+---------------+
                        v
                VALIDATION CONTEXT
                        |
                        v
                VALIDATION ENGINE
                        |
                        v
                OBJECT VALIDATION
                        |
                        v
              REVIEW / CORRECTION
                        |
                        v
                DELIVERY APPROVAL
                        |
                        v
                  APPROVAL GATE
                        |
                        v
          CANONICAL INFORMATION PRODUCT
                        |
                        v
          PERSISTENCE / HISTORY / EVIDENCE
                        |
        +---------------+----------------+
        |               |                |
        v               v                v
   CHANGE INTELLIGENCE  AIS / CURRENT   ANALYTICS
        |               |                |
        +---------------+----------------+
                        v
          FM / AIM / GIS / CDE / API / DT
```

## 5. Architecture layer register

| # | Layer | Responsibility | Current state |

| --- | --- | --- | --- |

| 01 | Source / Authoring | Revit, Dynamo/Python, IFC; planned/expanded DWG, PDF, Excel, GIS, scan, CDE and FM sources | GREEN in proven source scope; legacy adapters future |

| 02 | Acquisition / Adapters | Source import/export, raw-file hashing, normalization, project/property/building extraction | GREEN in proven adapters; more adapters planned |

| 03 | Source Identity & Integrity | SHA-256, source/run/building/project identity, source precedence, freshness, fail-closed | GREEN |

| 04 | Governed Project Context | Organisation -> Project -> Property -> Building -> Stage -> Delivery Cycle | DESIGNED / successor work; UI context decisions established |

| 05 | Requirement Authority | Requirement Set/Version, rule identity, severity, applicability, provenance, publication | GREEN / requirement library completed and closed in verified scope |

| 06 | Reference Authority | Allowed values, controlled values, classifications, exact reference content identity | GREEN |

| 07 | Validation Context | Immutable binding of requirement + reference + project/context selection | GREEN |

| 08 | Validation Engine | Room/area/property/identity/classification checks with STOP/WARNING/INFO/PASS/BLOCKED | GREEN |

| 09 | Object Validator | Walls, doors, windows, boundaries, links, object issues and bound result identity | GREEN |

| 10 | Correction / AutoFix | Correction proposals, preview, human Correction Approval, Compare-Before-Write | GREEN in scoped flows |

| 11 | Review Lifecycle | Review session, sealed bundle, audit, corrections, Delivery Approval | GREEN |

| 12 | Approval Gate | Fresh source + verified authority + review binding; BLOCKED cannot be approved | GREEN |

| 13 | Canonical Information Product | Approved artifact with source, validation, approval, provenance and authority identity | GREEN |

| 14 | Persistence / History | Approved Inbox, SQLite/project DB, history, object evidence, reports | GREEN in scoped implementation |

| 15 | AIS / Verified Publish / Current | Organisation acceptance / AIS / current semantics and publication authority | NEXT after Product Workspace |

| 16 | Baseline & Change Control | Declared baseline, comparison target, governed delta, baseline decision | NEXT after AIS/Current |

| 17 | Change Intelligence V1 | ADDED/REMOVED/UNCHANGED/PROPERTY_CHANGED/IDENTITY_UNCERTAIN, deterministic evidence | FINAL FROZEN V0.12 |

| 18 | Reality / Point Cloud Viewer | E57/point cloud/360 context and measurement | SEPARATE TRACK; not Core authority |

| 19 | Analytics / Reporting | Validation reports, Power BI, geometry/ROI and future portfolio analytics | GREEN / expandable |

| 20 | Product Workspace / UI | Organisation/Project/Building/Information Product workspace, changes, review, publish, admin | IMMEDIATE NEXT - walking skeleton |

| 21 | Downstream Consumers | FM/AIM/GIS/CDE/API/Digital Twin / operations | INTEGRATION TARGETS |



## 6. Development journey - idea to current frozen CI authority

| Period | Milestone | What changed |

| --- | --- | --- |

| Jun 2026 | First practical validation chain | Revit/Dynamo -> JSON -> requirement checks -> issues -> approval direction. Abboten 12-room proof established a useful end-to-end concept. |

| Jun 2026 | Platform direction | Focus moved from scripts to a platform: dashboard/approval, requirements, issues, 2D/3D, database, export and owner requirements. Revit became a source, not the workflow centre. |

| Jun-Aug 2026 | Source breadth and scale | IFC/OpenBIM, geometry, 2D/3D review, multi-building, source parity and larger Region Blekinge models were added. Akuten Run01 demonstrated scale and fail-closed behaviour. |

| 14-23 Aug 2026 | Correction governance | Controlled corrections, AutoFix proposals, Correction Approval, Translator, Compare-Before-Write and source-specific correction boundaries were established. |

| Late Aug 2026 | Identity/history/portability | Duplicate GUID protection, source precedence, Windows/Python portability, history/analytics and IFC/Revit parity became explicit concerns. |

| Early Sep 2026 | Governance hardening | NO_EFFECTIVE_RULES behaviour, fail-closed policy, Requirement/Reference persistence and provenance were hardened. |

| 17-19 Sep 2026 | S11-S19 semantic successor chain | Reference -> Mapping -> Identity -> Context -> Binding -> Property Authority -> Baseline -> AIS -> Verified Publish / Current semantics were progressively separated and frozen by scope. |

| 19-21 Sep 2026 | Productization / Regression01 | SQLite/repository and administration work. Regression Attempt21 remained NOT_PROVEN instead of being forced green; 27 PASS / 64 NOT_PROVEN / 0 FAIL. |

| 21-24 Sep 2026 | Information Product / UI REV2 | Project Context, delivery cycles, Organisation Acceptance, AIS and Current were separated as explicit authorities. OD-18/OD-02/OD-01 decisions refined cycle and Current semantics. |

| Late Sep-4 Oct 2026 | Requirement governance / RLCB / Windows E2E | No-code governed requirement lifecycle, exact Requirement/Reference content binding, real IFC, Approval Gate and DB persistence were strengthened. |

| 5-6 Oct 2026 | F59 / m-66-1 / G-B1 / REV10 | Runtime hardening, approval-session binding and reviewer-identity scopes closed and became frozen authorities. REV10 became a continuity baseline for the integrated state. |

| 6-8 Oct 2026 | DP-01 deployment successor | Deployment/productization was contracted and tested through V1-V5. Representative real IFC W4 was successful, but final closure remained NOT ACCEPTED because evidence/acceptance residuals remained NOT_PROVEN. |

| 8-9 Oct 2026 | CI-01 Change Intelligence V1 | V0.1-V0.12 passed successive hard reviews. Identity, canonicalization, failure-evidence, NaN-key and traversal/depth issues were closed through narrow successors. V0.12 then passed Review99 and Windows review, and was Accepted -> Promoted -> Final -> Frozen. |

| 9 Oct 2026 | Current handoff point | Archive/continuity update is now required. Product Workspace Walking Skeleton is the next recommended implementation track; CI-01 V0.12 must not be modified. |



## 7. What the platform already does

- Ingests governed source data in proven Revit/Dynamo/IFC flows and binds source identity/hash.

- Applies exact Requirement and Reference authorities through a Validation Context.

- Validates rooms/areas/properties/identity/classification and object-level entities such as walls, doors, windows, boundaries and links.

- Produces governed issues with STOP/WARNING/INFO/PASS/BLOCKED semantics and preserves upstream findings when no effective rules execute.

- Supports correction proposals/AutoFix with human Correction Approval; writeback is separate from approval of delivery/publication.

- Uses review sessions, sealed bundles and Delivery Approval before Approval Gate.

- Creates a Canonical Information Product only from fresh source and verified bindings.

- Persists governed approved information/history and supports reports/analytics.

- Now provides frozen Change Intelligence Slice 1 for deterministic state-to-state change detection without silent identity guessing.



## 8. Requirement / Reference governance and PTS direction

The Requirement Library is already completed, verified and closed within its proven scope. Future BEP or customer mapping work must reuse it rather than rebuild it. Reference Authority manages allowed values/classification/reference content. Exact contents are hashed/bound into Validation Context and downstream evidence.

The PTS direction was split conceptually into Level 1 automatically verifiable model information (e.g. rooms/areas/doors/windows/classification/heights/fire/acoustic), Level 2 mixed automatic + human verification (e.g. free clearances, accessibility, daylight, hygiene/cleanability), and Level 3 document/manual evidence. The platform should keep this separation: automatic detection does not replace professional assessment.

## 9. Correction, review, delivery and publication are intentionally separate

Correction Approval authorizes a correction action; it does not make preview data canonical. Revit writeback must use Compare-Before-Write and a fresh export/revalidation. IFC correction is done at source and re-exported. Delivery Approval permits progression to Approval Gate but creates no canonical/current truth by itself. Organisation Acceptance, AIS and Verified Publish/Current remain separate authorities.

## 10. Frozen / authoritative scopes and identity register

| Authority | Status | SHA-256 | Role / boundary |

| --- | --- | --- | --- |

| S19 VPC-01 Core | FINAL FROZEN | 3BEB862A7DCA6BCC18D18AFB7B8DD08D093EBA3F615D55A83EE39CE91EDA1A64 | Verified Publish / Current semantic authority in its exact scope; do not reinterpret through later UI work. |

| RLCB V2 | Frozen authority | EFF884F3A616D7D17CD9ADFF9A1B32A366F6D1E4A4C5D77A98BF1B7254863E39 | Exact Requirement/Reference content binding authority. |

| F59 V4 | FINAL FROZEN | 81E5B4D2C085C5DE76CCB6E9C80DA893EF10F6A34D919421D8F0A2D5ADA223BD | Runtime hardening authority. |

| m-66-1 | FINAL FROZEN | 5E1938CBEC0EA891431404216C760CF24B02E3207CA3C52B1FBE0457BAF2B64D | Approval-session binding authority. |

| G-B1 | FINAL FROZEN | 32778DBFD69E9E5A27CCDF71CCCA016106CB6EE1987A1B64C1237D92206D2510 | Reviewer identity / gate binding scope. |

| CI-01 Slice 1 V0.12 | ACCEPTED + PROMOTED + FINAL + FROZEN | 2F45BC7E37809802E1BF385755AEAF7215BC05D0C5308A27F0EE31D57A0BE577 | Change Intelligence narrow scope only: ADDED, REMOVED, UNCHANGED, PROPERTY_CHANGED, IDENTITY_UNCERTAIN. |



## 11. REV10 continuity baseline

REV10 archive SHA-256: `1D2B3C1D7E16FEF3597F2FE86AE1E9704DA9B23B1BAAAA8B1F56D65C4F3BAFC6`

REV10 Current State SHA-256: `6651D314F1DB75C1502433D282B81E94AE5E4AD8CEFC50A7963F4650B7F7C7E2`

REV10 Handoff Record SHA-256: `437A13BE4D4A865F910FD1CCEE593085BD002EC37D8AFDE37BD59770668F7252`

REV10 remains important for the integrated pre-CI continuity baseline. This 2026-10-09 package updates the narrative/current working state but does not rewrite REV10 primary evidence.

## 12. DP-01 deployment/productization - exact current disposition

V5 candidate SHA-256: `A80523A6ADD0B6B621DD6FD279F91A65FD620616A5E376EE7AB4DA48C211D4BB`; product-tree identity: `1688AD93C13FE7B76C65ACD841C44EF93A4CEA08935CA55083178B0D7B100FDD`.

The representative W4 real-IFC flow succeeded: real IFC import -> review -> sealed bundle -> bound object validation -> Delivery Approval -> Approval Gate -> persistence -> delivered session, with product integrity preserved. However DP-01 closure remained deliberately NOT ACCEPTED / NOT PROMOTED / NOT FINAL / NOT FROZEN. The builder closure recorded 28/30 acceptance criteria PASS, 0 FAIL, with AC-02 and AC-17 NOT_PROVEN; Review85 further identified independent-evidence/provenance and handoff-fitness gaps. The safe rule is to preserve the disposition, not reinterpret it as success.

Do not repack V5 merely to clean stale metadata. Do not use historical Windows evidence that was never independently reviewed as if it were independently proven. If DP-01 is ever reopened, use the exact primary evidence and a new formal review/decision chain.

## 13. CI-01 Change Intelligence V1 - complete successor history

| Version | Evidence | Review result | Reason / closure |

| --- | --- | --- | --- |

| V0.1 | 12/12 builder tests; Review88 | 0 B / 3 M / 6 m | Duplicate identity and authority-conflict issues; successor required. |

| V0.2 | 24/24 tests | No independent primary review performed | Important provenance fact: no independent V0.2 review existed; do not reconstruct one. |

| V0.3 | 35/35 tests; Review90 | 1 B / 4 M / 2 m | Numeric overflow, invalid roots, missing schema, authority-gate/provenance gaps. |

| V0.4 | 46/46 tests | 0 B / 2 M / 2 m | Provenance and exact semantic hash runtime verification remained. |

| V0.5 | 52/52 tests; Review92 | 1 B / 3 M / 3 m | Runtime authority set regressed; exact delta/evidence/schema issues. |

| V0.6 | 60/60 tests; Review93 | 0 B / 1 M / 1 m | Early authority failure did not preserve actual caller configuration evidence. |

| V0.7 | 63/63 tests; Review94 | 0 B / 1 M / 0 m | Non-standard configuration evidence could collapse distinct explicit configs. |

| V0.8 | 68/68 tests; Review95 | 1 B / 1 M / 0 m | Schema-invalid early authority failures; lone-surrogate crash path. |

| V0.9 | 75/75 tests; Review96 | 1 B / 1 M / 0 m | Non-string mapping-key coercion and configuration evidence ambiguity. |

| V0.10 | 83/83 tests; Review97 | 1 B / 0 M / 0 m | Distinct NaN mapping keys could collide inside explicitly supported V2 fingerprint domain. |

| V0.11 | 87/87 tests; Review98 | 0 B / 1 M / 0 m | NaN collision closed via bounded-domain V3; new recursion/depth fail-closed gap found. |

| V0.12 | 95/95 tests; Review99 | 0 B / 0 M / 0 m | Traversal-domain guard closes cycles/depth. Fit for owner decision; subsequently Accepted, Promoted, Windows-reviewed, Final, Frozen. |



### 13.1 Frozen CI-01 V0.12 exact state

Candidate SHA-256: `2F45BC7E37809802E1BF385755AEAF7215BC05D0C5308A27F0EE31D57A0BE577`

Authorized/frozen Slice 1 change types: ADDED, REMOVED, UNCHANGED, PROPERTY_CHANGED, IDENTITY_UNCERTAIN. No MOVED/RESIZED, geometry-change semantics, classification/relationship changes, requirement impact, writeback, baseline replacement or Current mutation are authorized by this frozen scope.

Review99: BLOCKER 0 / MAJOR 0 / MINOR 0; FIT FOR FORMAL OWNER ACCEPTANCE DECISION. Windows runtime review on Python 3.14.5 with jsonschema 4.26.0 and rfc3339-validator 0.1.4 produced 95/95 PASS, pre/post SHA256SUMS 124/124 PASS, zero .pyc and zero __pycache__. The owner then separately executed Acceptance -> Promotion -> FINAL -> FROZEN. Future CI changes require a new successor, not V0.13-by-editing.

## 14. UI / Product Workspace decisions already made

UI REV2 separated project context, delivery cycles, organisation acceptance/AIS/Current and derived views. Key decisions included OD-18 delivery-cycle types/final-cycle logic, OD-02 AIS sealing only after verified organisation acceptance and exact cycle/delivery/snapshot/canonical payload binding, and OD-01 Current as exact-project-context authority rather than an independently mutable derived layer. These decisions should guide the Product Workspace but not be reimplemented as hidden client logic.

## 15. Reality Viewer and Model Health are separate tracks

Reality/Point Cloud Viewer work (including E57/360 use) is valuable for visual context, scan/model comparison and measurement, but it is not a substitute for Core information authority. Model Health (geometric/model quality) and Information Health (requirements, identity, approval, provenance) should remain distinguishable even when presented in one workspace.

## 16. Current status matrix

| Area | State | What this means |

| --- | --- | --- |

| Core validation/governance | MATURE / frozen authorities by scope | Do not rewrite frozen scopes; build additive successors/integrations. |

| Requirement Library | COMPLETED / CLOSED in verified scope | Reuse; do not rebuild. |

| CI-01 Slice 1 | FINAL FROZEN | Read-only authority for the authorized change taxonomy. |

| DP-01 | CLOSED but NOT ACCEPTED | Preserve NOT_PROVEN and Review85 caveats. |

| Product Workspace | NEXT | Build walking skeleton consuming governed outputs. |

| AIS / Verified Publish / Current | SEMANTICS FROZEN, product realization next | Implement after Workspace without collapsing decision boundaries. |

| Baseline / Change Control | PLANNED NEXT | Use CI against a declared baseline with explicit replacement decision. |

| Legacy sources | PLANNED | Needed for PDF/DWG/scan-heavy customers and MENA. |

| Reality Viewer | SEPARATE | Continue independently; integrate presentation later. |



## 17. Open residuals / what is not finished

| Track | Status | Required treatment |

| --- | --- | --- |

| DP-01 | NOT ACCEPTED / NOT PROMOTED / NOT FINAL / NOT FROZEN | V5 closure was locally sound but Review85 found evidence/provenance and handoff-fitness gaps; AC-02 and AC-17 remained NOT_PROVEN in builder closure. Reopen only with exact evidence and a new formal decision path. |

| Windows long-path residual | OPEN / OUT OF SCOPE | Keep visible; do not retroactively claim it closed. |

| Product Workspace | NOT YET BUILT | Walking skeleton is immediate next product work. |

| AIS / Current runtime realization | NOT YET CLOSED | Semantics exist in frozen authorities; product/runtime realization remains a successor/integration task. |

| Baseline / Change Control | NOT YET CLOSED | Needed to operationalize CI against approved baselines. |

| Legacy PDF/DWG/GIS/scan adapters | PLANNED | Critical for markets/projects without BIM; must preserve source provenance and uncertainty. |

| Reality Viewer | SEPARATE TRACK | E57/point cloud/360 viewer work remains separate from Core truth authority. |



## 18. Roadmap from today

| Phase | When | Deliverable / rule |

| --- | --- | --- |

| R0 - Archive / continuity update | NOW | Create one coherent 2026-10-09 continuity archive, file map and AI handoff. Do not change frozen technical authorities. |

| R1 - Product Workspace Walking Skeleton | NEXT | Thin read-first UI: Organisation/Project/Building -> Information State A/B -> Compare -> Change Set -> changes/evidence/review status. Consume CI-01 read-only. |

| R2 - AIS / Verified Publish / Current | AFTER R1 | Realize publication/current workflows without collapsing Correction, Delivery, Organisation Acceptance, AIS and Current into one decision. |

| R3 - Baseline & Change Control | AFTER R2 | Declare governed baseline, compare new state through CI-01, review impact and make explicit baseline replacement decisions. |

| R4 - No-code onboarding | PARALLEL/AFTER R1 | Configuration-driven requirement/reference onboarding, controlled publication, mappings, code lists and project templates; Requirement Library itself is already complete in verified scope. |

| R5 - Legacy source adapters | PLANNED | PDF/DWG/Excel/GIS/scan/CDE intake for markets where BIM models are missing. Normalize into governed information states; never pretend legacy data has BIM identity it does not possess. |

| R6 - Pilot / customer packaging | PLANNED | Region Blekinge reference pilot, then customer packages for healthcare/municipal/MENA use. Separate software authority from customer configuration. |

| R7 - BEP & Information Requirements Compliance | OPTIONAL FUTURE | Add BEP-to-existing-requirement mapping/compliance UI as a successor/integration. Do not rebuild the completed Requirement Library or disrupt current priorities. |

| R8 - Extended CI successor | ONLY WHEN NEEDED | Future MOVED/RESIZED, geometry, classification, relationship or requirement-impact changes require a new CI successor. Never edit V0.12. |



## 19. Product Workspace Walking Skeleton - recommended first implementation slice

The first workspace should be deliberately thin and read-oriented. It should demonstrate the governed owner-flow without redesigning Core: Organisation -> Project -> Building -> Information Product / Information State -> select A/B -> Compare -> Change Set -> individual change -> evidence/review status. It should show summary counts such as added/removed/property-changed/identity-uncertain and let users inspect evidence/authority identities.

- No new CI semantics in the UI.

- No client-side override of fail-closed decisions.

- No hidden latest-version fallback.

- Derived views are read-only unless an explicit governed write path exists.

- UI should expose authority/evidence identifiers sufficiently for audit, while presenting human-friendly labels for normal users.

- Start with one pilot context; generalise only after the walking skeleton is stable.



## 20. Development work with code vs without code

| Mode | Examples | Governance rule |

| --- | --- | --- |

| With code | Product Workspace UI, read APIs, CI result presentation, AIS/Current runtime realization, baseline service, adapters for DWG/PDF/Excel/GIS/scan/CDE, connectors, test/evidence harnesses | New code must be scoped as Core successor, UI/Product Workspace, Reality Viewer, deployment/productization, connector or non-code governance before implementation. |

| Without code | Requirement/reference configuration, mapping tables, delivery-cycle templates, acceptance procedures, review checklists, user roles, operating instructions, pilot setup, customer onboarding, training, business packaging | Configuration must still be governed/versioned. Non-code does not mean non-governed. |

| Hybrid | BEP compliance mapping, PTS onboarding, customer-specific rules, issue workflows | Reuse frozen/verified foundations; keep customer configuration separate from shared product code. |



## 21. Commercial / pilot direction

Region Blekinge remains the strongest reference environment because real hospital/building data has been used throughout development. For Middle East opportunities - especially healthcare, municipal information systems, BIM/IM, digital handover, GIS+BIM and FM/asset data - the platform should be positioned as an information-governance and validation layer, not only a BIM checker. Where BIM is absent, the roadmap should ingest legacy PDF/DWG/Excel/GIS/scan sources with explicit uncertainty/provenance rather than requiring a BIM model before the platform can create value.

## 22. Files and authority map - what is needed and where it is

| Pri | Track | File / artifact | SHA-256 / ID | Known location | Why keep it |

| --- | --- | --- | --- | --- | --- |

| P0 | Current frozen CI-01 candidate | CI01_SLICE1_IMPLEMENTATION_CANDIDATE_V0_12_2026-10-08.zip | 2F45BC7E37809802E1BF385755AEAF7215BC05D0C5308A27F0EE31D57A0BE577 | Included in this archive | Exact immutable CI-01 Slice 1 frozen bytes. |

| P0 | CI-01 Acceptance | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_ACCEPTANCE_2026-10-09.zip | D641DF095FAB8641A74E0CEC894366EF299B0385AF16C2C7E277D3AF394A2D9B | Included in this archive | Formal acceptance evidence. |

| P0 | CI-01 Promotion | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_PROMOTION_2026-10-09.zip | DB90E2DA488D00ED8AECC75AAD85DA7739353C06A05A09A56C36F42242B0A122 | Included in this archive | Formal promotion evidence. |

| P0 | CI-01 Windows closure | CI01_SLICE1_V0_12_WINDOWS_RUNTIME_REVIEW_CLOSURE_2026-10-09.zip | 959A41FCBCF5AE81D54ABA9B20F1BDD58C676F18BB019B283AC5A2A4CAAD9511 | Included in this archive | Windows runtime closure; original owner Windows evidence file remains on Windows and should also be retained. |

| P0 | CI-01 FINAL | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_FINAL_DESIGNATION_2026-10-09.zip | 085F8DC71AE4D20484BA5FF721E6F5656A4F32183A567CE23A5634B528989E10 | Included in this archive | FINAL designation evidence. |

| P0 | CI-01 FROZEN | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_FROZEN_DESIGNATION_2026-10-09.zip | C5C45D3D9460DFD41AECA5B796CB5457CC5971719D8A008B4055A54C8C5CC1F7 | Included in this archive | Frozen designation evidence. |

| P0 | Original Windows CI evidence | CI01_V012_WINDOWS_RUNTIME_EVIDENCE_2026-10-09.txt | 43D5FEC4B86360204292A18BDAD4E121CEFF31CA2CF15BA74AA607C5FFB93E92 | C:\Users\bouadi\CI01_WINDOWS_REVIEW_V012\ | Retain original file; this continuity archive contains owner receipt/closure, not reconstructed original bytes. |

| P0 | DP-01 V5 candidate | IM_PLATFORM_DP01_DEPLOYMENT_SUCCESSOR_CANDIDATE_V5_2026-10-08.zip | A80523A6ADD0B6B621DD6FD279F91A65FD620616A5E376EE7AB4DA48C211D4BB | C:\Users\bouadi\DP01W\V5C\ | Do not relabel as accepted. Preserve exact V5 plus closure evidence. |

| P0 | DP-01 closure assessment | 00_DP01_V5_FORMAL_CLOSURE_ASSESSMENT.txt | 7C14CBD22D2B06CBDBAB8A8BBEF1D9BAB3A8F40C09BC31A9C93B6831126CCE45 | C:\Users\bouadi\DP01W\V5_FINAL_CLOSURE\ATTEMPT01\ | Formal closure assessment. |

| P0 | DP-01 closure binding | 01_DP01_V5_FINAL_CLOSURE_STATUS_BINDING.json | 936E16B8AA5D59E7215B526BC7030A4C6600C7EB8B4FA96FD1DF59281EAD1E2D | C:\Users\bouadi\DP01W\V5_FINAL_CLOSURE\ATTEMPT01\ | Keeps DP-01 NOT ACCEPTED etc. |

| P0 | Review85 | 85_DP01_V5_CLOSURE_AND_ARCHIVE_HANDOFF_REVIEW.md | BC/see file hash in archive manifest | Included under historical reference | Independent review of DP-01 closure/handoff fitness. |

| P0 | REV10 Continuity Archive | authoritative REV10 archive | 1D2B3C1D7E16FEF3597F2FE86AE1E9704DA9B23B1BAAAA8B1F56D65C4F3BAFC6 | Typically C:\Users\bouadi\Downloads\ / prior archive folder | Continuity baseline for pre-DP/CI integrated state. Locate exact file by hash if authority work is needed. |

| P0 | REV10 Current State | REV10 current-state record | 6651D314F1DB75C1502433D282B81E94AE5E4AD8CEFC50A7963F4650B7F7C7E2 | Inside REV10 continuity archive | Machine-readable state baseline. |

| P0 | REV10 Handoff Record | REV10 handoff record | 437A13BE4D4A865F910FD1CCEE593085BD002EC37D8AFDE37BD59770668F7252 | Inside REV10 continuity archive | Continuity/handoff binding. |

| P1 | S19 VPC-01 frozen authority | exact S19 package | 3BEB862A7DCA6BCC18D18AFB7B8DD08D093EBA3F615D55A83EE39CE91EDA1A64 | C:\Users\bouadi\Downloads\ / master archives | Use only exact bytes for S19 authority work. |

| P1 | RLCB V2 | exact frozen package | EFF884F3A616D7D17CD9ADFF9A1B32A366F6D1E4A4C5D77A98BF1B7254863E39 | C:\Users\bouadi\Downloads\ | Requirement/Reference exact content binding. |

| P1 | F59 V4 | exact frozen package | 81E5B4D2C085C5DE76CCB6E9C80DA893EF10F6A34D919421D8F0A2D5ADA223BD | C:\Users\bouadi\Downloads\ | Runtime hardening authority. |

| P1 | m-66-1 | exact frozen package | 5E1938CBEC0EA891431404216C760CF24B02E3207CA3C52B1FBE0457BAF2B64D | C:\Users\bouadi\Downloads\ | Approval-session binding authority. |

| P1 | G-B1 | exact frozen package | 32778DBFD69E9E5A27CCDF71CCCA016106CB6EE1987A1B64C1237D92206D2510 | C:\Users\bouadi\Downloads\ | Reviewer/gate binding authority. |

| P2 | 10/07 Master Dossier | IM_PLATFORM_MASTER_PROJECT_DOSSIER_2026-10-07_POST_REV10_DP01_W4.docx/pdf | see 10/07 SHA256SUMS | Included under historical reference | Historical continuity narrative; superseded narratively by this 10/09 package, not technical authority. |

| P2 | Reality Viewer evidence | MVP02D / E57 candidate and related viewer files | n/a | Project/Windows archive; E57 candidate Z00-0210-00-Panorama.e57 | Separate track; large source files may be archived separately. |



## 23. What this new archive physically contains

- Current 2026-10-09 Master Project Dossier (DOCX/PDF/MD).

- Current Working State JSON.

- Architecture & Roadmap summary.

- Project history index.

- File/authority map and source-collection checklist.

- Ready-to-paste ChatGPT and Claude continuation prompts.

- Current CI-01 V0.12 candidate plus Acceptance, Promotion, Windows Review Closure, FINAL and FROZEN packages.

- Historical 2026-10-07 dossier/roadmap/history/prompts and Review85 as reference material.

- SHA256SUMS for this archive.



It does NOT contain every raw historical ZIP ever produced, every point-cloud/IFC source file, or a verbatim export of all chats. The source-collection guide identifies the exact primary files that should also be retained on long-term storage. This prevents a narrative archive from pretending to replace technical authority.

## 24. How a new developer/AI should continue

- Read README_FIRST, Current Working State JSON, this dossier and File/Authority Map before proposing changes.

- Classify every requested task before coding: Core successor, UI/Product Workspace, Reality Viewer, deployment/productization, connector or non-code governance.

- Identify the exact frozen parent/authority relevant to the task and verify its bytes/hash before modifying anything.

- Create a new successor/staging copy for any frozen-scope change.

- Keep technical implementation, review, acceptance, promotion, FINAL and FROZEN as separate transitions.

- For Windows/PowerShell, use one short safe logical block at a time and wait for observed output before the next dependent step.

- If this narrative conflicts with later exact primary evidence, the later exact primary evidence wins.



## 25. Glossary

| Term | Meaning |

| --- | --- |

| Information Product | Governed output with exact source, requirement/reference, validation, approval and provenance identity. |

| Requirement Authority | Versioned owner requirements/rules and applicability. |

| Reference Authority | Controlled values/classifications/reference content. |

| Validation Context | Immutable binding of exact requirements, references and project context used for an execution. |

| Correction Approval | Human permission to apply a correction; not delivery/current approval. |

| Delivery Approval | Allows progression of a reviewed delivery to Approval Gate. |

| AIS | Acceptance Information Set / sealed acceptance snapshot in the project semantics. |

| Current | Exact project-context current published authority; derived views should not create independent mutable Current. |

| Baseline | Explicit approved comparison reference for controlled change management. |

| CI-01 | Change Intelligence successor; V0.12 Slice 1 is frozen in narrow scope. |

| DP-01 | Deployment/productization successor; V5 closure remains not accepted. |

| FINAL FROZEN | Formal state that makes exact bytes immutable in their governed scope; future change requires successor. |



## 26. Source basis / limitations

This dossier synthesizes the project conversation history available in the ChatGPT project, project knowledge/memory, the 2026-10-07 Master Dossier/History/Architecture files, Review85, and the exact CI-01 governance chain created on 2026-10-09. It is not a verbatim transcript archive. Exact primary files and formal hashes remain the source of truth for any authority claim.
