# IM Platform - Architecture & Roadmap (2026-10-09)

## Authority boundary
Continuity summary only. Exact primary artifacts and formal governance evidence outrank this text.

## Master flow
```text
SOURCE WORLD
Revit / Dynamo / IFC / later DWG / PDF / Excel / GIS / Scan / CDE / FM
        |
        v
SOURCE IDENTITY + NORMALIZATION
        |
        v
GOVERNED PROJECT / BUILDING / STAGE / DELIVERY CONTEXT
        |
        +-------------------------------+
        |                               |
        v                               v
REQUIREMENT AUTHORITY             REFERENCE AUTHORITY
        |                               |
        +---------------+---------------+
                        v
                VALIDATION CONTEXT
                        |
                        v
                VALIDATION ENGINE
                        |
                        v
                OBJECT VALIDATION
                        |
                        v
              REVIEW / CORRECTION
                        |
                        v
                DELIVERY APPROVAL
                        |
                        v
                  APPROVAL GATE
                        |
                        v
          CANONICAL INFORMATION PRODUCT
                        |
                        v
          PERSISTENCE / HISTORY / EVIDENCE
                        |
        +---------------+----------------+
        |               |                |
        v               v                v
   CHANGE INTELLIGENCE  AIS / CURRENT   ANALYTICS
        |               |                |
        +---------------+----------------+
                        v
          FM / AIM / GIS / CDE / API / DT
```

## Immediate state
- CI-01 Slice 1 V0.12: ACCEPTED / PROMOTED / FINAL / FROZEN.
- DP-01 V5: NOT ACCEPTED / NOT PROMOTED / NOT FINAL / NOT FROZEN.
- Next implementation: Product Workspace Walking Skeleton.
- Then: AIS / Verified Publish / Current -> Baseline & Change Control -> no-code onboarding / legacy adapters / pilot packaging.

## Rule
Never modify frozen bytes. Any change to CI semantics requires a new successor.
