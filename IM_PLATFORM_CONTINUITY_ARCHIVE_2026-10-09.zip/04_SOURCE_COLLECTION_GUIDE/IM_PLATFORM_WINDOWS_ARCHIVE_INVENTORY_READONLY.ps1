# IM Platform - read-only archive inventory helper
# Does NOT copy, delete, modify or hash-rewrite project files.
$roots = @(
  "$env:USERPROFILE\Downloads",
  "$env:USERPROFILE\Documents",
  "$env:USERPROFILE\Desktop",
  "$env:USERPROFILE\DP01W",
  "$env:USERPROFILE\CI01_WINDOWS_REVIEW_V012"
) | Where-Object { Test-Path $_ }

$patterns = @(
  'IM_PLATFORM_*',
  'CI01_*',
  'DP01_*',
  'REFERENCE_LIBRARY_*',
  'REVIEW_*',
  '*REV10*'
)

$result = foreach ($root in $roots) {
  foreach ($pat in $patterns) {
    Get-ChildItem $root -Recurse -Force -File -Filter $pat -ErrorAction SilentlyContinue |
      Select-Object FullName,Length,LastWriteTime
  }
}

$result | Sort-Object FullName -Unique | Export-Csv "$env:USERPROFILE\Desktop\IM_PLATFORM_WINDOWS_FILE_INVENTORY.csv" -NoTypeInformation -Encoding UTF8
$result | Sort-Object FullName -Unique | Format-Table -AutoSize
