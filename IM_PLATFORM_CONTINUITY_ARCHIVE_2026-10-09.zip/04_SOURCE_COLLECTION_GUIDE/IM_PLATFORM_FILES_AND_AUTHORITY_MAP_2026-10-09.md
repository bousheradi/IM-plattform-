# IM Platform - Files & Authority Map (2026-10-09)
This is the operational answer to "which files are needed and where are they?". P0 = preserve first.
| Pri | Track | File / artifact | SHA-256 / ID | Known location | Why keep it |
|---|---|---|---|---|---|
| P0 | Current frozen CI-01 candidate | CI01_SLICE1_IMPLEMENTATION_CANDIDATE_V0_12_2026-10-08.zip | 2F45BC7E37809802E1BF385755AEAF7215BC05D0C5308A27F0EE31D57A0BE577 | Included in this archive | Exact immutable CI-01 Slice 1 frozen bytes. |
| P0 | CI-01 Acceptance | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_ACCEPTANCE_2026-10-09.zip | D641DF095FAB8641A74E0CEC894366EF299B0385AF16C2C7E277D3AF394A2D9B | Included in this archive | Formal acceptance evidence. |
| P0 | CI-01 Promotion | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_PROMOTION_2026-10-09.zip | DB90E2DA488D00ED8AECC75AAD85DA7739353C06A05A09A56C36F42242B0A122 | Included in this archive | Formal promotion evidence. |
| P0 | CI-01 Windows closure | CI01_SLICE1_V0_12_WINDOWS_RUNTIME_REVIEW_CLOSURE_2026-10-09.zip | 959A41FCBCF5AE81D54ABA9B20F1BDD58C676F18BB019B283AC5A2A4CAAD9511 | Included in this archive | Windows runtime closure; original owner Windows evidence file remains on Windows and should also be retained. |
| P0 | CI-01 FINAL | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_FINAL_DESIGNATION_2026-10-09.zip | 085F8DC71AE4D20484BA5FF721E6F5656A4F32183A567CE23A5634B528989E10 | Included in this archive | FINAL designation evidence. |
| P0 | CI-01 FROZEN | CI01_SLICE1_V0_12_FORMAL_PRODUCT_OWNER_FROZEN_DESIGNATION_2026-10-09.zip | C5C45D3D9460DFD41AECA5B796CB5457CC5971719D8A008B4055A54C8C5CC1F7 | Included in this archive | Frozen designation evidence. |
| P0 | Original Windows CI evidence | CI01_V012_WINDOWS_RUNTIME_EVIDENCE_2026-10-09.txt | 43D5FEC4B86360204292A18BDAD4E121CEFF31CA2CF15BA74AA607C5FFB93E92 | C:\Users\bouadi\CI01_WINDOWS_REVIEW_V012\ | Retain original file; this continuity archive contains owner receipt/closure, not reconstructed original bytes. |
| P0 | DP-01 V5 candidate | IM_PLATFORM_DP01_DEPLOYMENT_SUCCESSOR_CANDIDATE_V5_2026-10-08.zip | A80523A6ADD0B6B621DD6FD279F91A65FD620616A5E376EE7AB4DA48C211D4BB | C:\Users\bouadi\DP01W\V5C\ | Do not relabel as accepted. Preserve exact V5 plus closure evidence. |
| P0 | DP-01 closure assessment | 00_DP01_V5_FORMAL_CLOSURE_ASSESSMENT.txt | 7C14CBD22D2B06CBDBAB8A8BBEF1D9BAB3A8F40C09BC31A9C93B6831126CCE45 | C:\Users\bouadi\DP01W\V5_FINAL_CLOSURE\ATTEMPT01\ | Formal closure assessment. |
| P0 | DP-01 closure binding | 01_DP01_V5_FINAL_CLOSURE_STATUS_BINDING.json | 936E16B8AA5D59E7215B526BC7030A4C6600C7EB8B4FA96FD1DF59281EAD1E2D | C:\Users\bouadi\DP01W\V5_FINAL_CLOSURE\ATTEMPT01\ | Keeps DP-01 NOT ACCEPTED etc. |
| P0 | Review85 | 85_DP01_V5_CLOSURE_AND_ARCHIVE_HANDOFF_REVIEW.md | BC/see file hash in archive manifest | Included under historical reference | Independent review of DP-01 closure/handoff fitness. |
| P0 | REV10 Continuity Archive | authoritative REV10 archive | 1D2B3C1D7E16FEF3597F2FE86AE1E9704DA9B23B1BAAAA8B1F56D65C4F3BAFC6 | Typically C:\Users\bouadi\Downloads\ / prior archive folder | Continuity baseline for pre-DP/CI integrated state. Locate exact file by hash if authority work is needed. |
| P0 | REV10 Current State | REV10 current-state record | 6651D314F1DB75C1502433D282B81E94AE5E4AD8CEFC50A7963F4650B7F7C7E2 | Inside REV10 continuity archive | Machine-readable state baseline. |
| P0 | REV10 Handoff Record | REV10 handoff record | 437A13BE4D4A865F910FD1CCEE593085BD002EC37D8AFDE37BD59770668F7252 | Inside REV10 continuity archive | Continuity/handoff binding. |
| P1 | S19 VPC-01 frozen authority | exact S19 package | 3BEB862A7DCA6BCC18D18AFB7B8DD08D093EBA3F615D55A83EE39CE91EDA1A64 | C:\Users\bouadi\Downloads\ / master archives | Use only exact bytes for S19 authority work. |
| P1 | RLCB V2 | exact frozen package | EFF884F3A616D7D17CD9ADFF9A1B32A366F6D1E4A4C5D77A98BF1B7254863E39 | C:\Users\bouadi\Downloads\ | Requirement/Reference exact content binding. |
| P1 | F59 V4 | exact frozen package | 81E5B4D2C085C5DE76CCB6E9C80DA893EF10F6A34D919421D8F0A2D5ADA223BD | C:\Users\bouadi\Downloads\ | Runtime hardening authority. |
| P1 | m-66-1 | exact frozen package | 5E1938CBEC0EA891431404216C760CF24B02E3207CA3C52B1FBE0457BAF2B64D | C:\Users\bouadi\Downloads\ | Approval-session binding authority. |
| P1 | G-B1 | exact frozen package | 32778DBFD69E9E5A27CCDF71CCCA016106CB6EE1987A1B64C1237D92206D2510 | C:\Users\bouadi\Downloads\ | Reviewer/gate binding authority. |
| P2 | 10/07 Master Dossier | IM_PLATFORM_MASTER_PROJECT_DOSSIER_2026-10-07_POST_REV10_DP01_W4.docx/pdf | see 10/07 SHA256SUMS | Included under historical reference | Historical continuity narrative; superseded narratively by this 10/09 package, not technical authority. |
| P2 | Reality Viewer evidence | MVP02D / E57 candidate and related viewer files | n/a | Project/Windows archive; E57 candidate Z00-0210-00-Panorama.e57 | Separate track; large source files may be archived separately. |
