# IM Platform - Source Collection Checklist (2026-10-09)

## Purpose
The new continuity archive contains the current handoff and the complete CI-01 V0.12 frozen chain that was available in this session. It is not a replacement for every historical primary artifact. Collect the P0/P1 files below into long-term storage before deleting old Windows downloads or project folders.

## P0 - collect / preserve first
1. Exact CI-01 V0.12 candidate and all governance packages (already included here).
2. Original Windows evidence file:
   `C:\Users\bouadi\CI01_WINDOWS_REVIEW_V012\CI01_V012_WINDOWS_RUNTIME_EVIDENCE_2026-10-09.txt`
   Expected SHA-256 `43D5FEC4B86360204292A18BDAD4E121CEFF31CA2CF15BA74AA607C5FFB93E92`.
3. DP-01 V5 candidate under `C:\Users\bouadi\DP01W\V5C\` with expected SHA-256 `A80523A6ADD0B6B621DD6FD279F91A65FD620616A5E376EE7AB4DA48C211D4BB`.
4. DP-01 formal closure folder `C:\Users\bouadi\DP01W\V5_FINAL_CLOSURE\ATTEMPT01\`.
5. REV10 continuity archive by SHA-256 `1D2B3C1D7E16FEF3597F2FE86AE1E9704DA9B23B1BAAAA8B1F56D65C4F3BAFC6` plus its Current State and Handoff records.
6. Exact S19/RLCB/F59/m-66-1/G-B1 frozen packages and signed freeze/promotion records.

## P1 - preserve for reproducibility / audit
- DP-01 W0-W5 evidence tree, Review83/84/85, contracts and owner decisions.
- Requirement/Reference library freeze and RLCB V2 evidence.
- Regression01 Attempt21 evidence and runtime closure.
- UI REV2 decision records (OD-01, OD-02, OD-18 and related context).
- Reality Viewer source/evidence, but keep large E57/point-cloud source files in a separate data archive.

## P2 - historical narrative / onboarding
- Prior master dossiers and archive/handoff bundles (2026-09-21, 2026-10-04, 2026-10-07).
- Old prototype/pilot packages such as v43/v48.

## Rule
Do not delete a historical primary artifact merely because a later narrative summarizes it. Narrative documents are for continuity; primary bytes are for authority and forensic audit.
