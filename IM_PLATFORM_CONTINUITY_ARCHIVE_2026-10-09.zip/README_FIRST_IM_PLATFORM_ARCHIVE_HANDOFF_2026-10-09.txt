IM PLATFORM - PROJECT CONTINUITY ARCHIVE / HANDOFF
Date: 2026-10-09
Owner / product lead: Bousher Adi

PURPOSE
This package lets a future ChatGPT/Claude session, developer, BIM/Information Manager, partner or owner understand the project from idea to current state and continue without restarting the architecture.

IMPORTANT AUTHORITY BOUNDARY
This package is a continuity/onboarding synthesis. It is NOT itself a new technical successor or a replacement for exact frozen authority bytes. Exact primary artifacts + SHA-256 + formal governance evidence outrank narrative.

CURRENT TOP-LINE STATE
- CI-01 Slice 1 V0.12: ACCEPTED / PROMOTED / FINAL / FROZEN. SHA-256 2F45BC7E37809802E1BF385755AEAF7215BC05D0C5308A27F0EE31D57A0BE577
- DP-01 V5: NOT ACCEPTED / NOT PROMOTED / NOT FINAL / NOT FROZEN. SHA-256 A80523A6ADD0B6B621DD6FD279F91A65FD620616A5E376EE7AB4DA48C211D4BB
- Immediate next: Product Workspace Walking Skeleton.
- Then: AIS / Verified Publish / Current -> Baseline & Change Control -> no-code onboarding / legacy adapters / pilot packaging.

READ ORDER
1. 06_MACHINE_READABLE/IM_PLATFORM_CURRENT_WORKING_STATE_2026-10-09.json
2. 01_CURRENT_HANDOFF/IM_PLATFORM_MASTER_PROJECT_DOSSIER_2026-10-09_POST_CI01_FROZEN.docx (or PDF/MD)
3. 04_SOURCE_COLLECTION_GUIDE/IM_PLATFORM_FILES_AND_AUTHORITY_MAP_2026-10-09.md
4. 01_CURRENT_HANDOFF/IM_PLATFORM_ARCHITECTURE_AND_ROADMAP_2026-10-09.md
5. 01_CURRENT_HANDOFF/IM_PLATFORM_PROJECT_HISTORY_INDEX_2026-10-09.md
6. 05_PROMPTS/ matching ChatGPT/Claude continuation prompt
7. Exact task-specific primary evidence.

AI PROJECT NAMES
- ChatGPT project: Information Management Platform (IM Platform)
- Claude project: IM PLATTFORM

RULE
If this package conflicts with later exact primary evidence, the later primary evidence wins.
